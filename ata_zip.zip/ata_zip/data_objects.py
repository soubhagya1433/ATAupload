vk_st0_data = {
    # "Kunde": "",
    # "Gegenstand": "",
    # "Zeichnungs- Nr.": "",
    # "Ausführen Nr.": "",
    "Fertigung Gesamt": 0,
    "bis 90mm Einsatz": 0,
    "bis 90mm Fertig": 0,
    "bis 90mm Preis": 0,
    "ab 100mm Einsatz": 0,
    "ab 100mm Fertig": 0,
    "ab 100mm Preis": 0,
    "Profile Einsatz": 0,
    "Profile fertig": 0,
    "Profile Preis": 0
}

vk0_data = {
    "Brennen": 0,
    "Richten": 0,
    "Heften_Zussamenb_Verputzen": 0,
    "Anzeichnen": 0,
    "Schweißen": 0
}

customers = [
    "Siemens Duisburg",
    "Siemens Berlin",
    "Siemens Erlangen",
    "Siemens Nürnberg",
    "Siemens München",
    "Siemens Karlsruhe",
    "OVGU Magdeburg",
]

# Define data types and properties
deckung_properties = {
    'Kunde': str,
    'Benennung': str,
    'Zeichnungs- Nr.': str,
    'Ausführen Nr.': str,
    'Gewicht': float,
    'Material Kosten': float,
    'Glühen': float,
    'Prüfen , Doku': float,
    'Strahlen / Streichen': float,
    'techn. Bearb.': float,
    'mech. Vorbearb.': float,
    'mech. Bearbeitung': float,
    'Zwischentransporte': float,
    'transporte': float,
    'Grenzkosten': float,
    'Erlös': float,
    'DB': float,
    'Deckungsbeitrag': float,
}

welding_units = {
    'Brennen': 'min',
    'Richten': 'min',
    'Heften_Zussamenb_Verputzen': 'min',
    'Anzeichnen': 'min',
    'Schweißen': 'min',
    'Nahtlänge': 'mm',
    'Nahtbreite': 'mm',
    'Blechdicke': 'mm',
    'Drahtdurchmesser': 'mm',
    'Masse Drahtelektrode': 'kg',
    'Stundensatz Schweißer': '€',
    'Kosten Drahtelektrode': '€/kg',
    'Schweißzeit gesamt': 'h',
    'Nebenzeit': 'h',
    'Schweißzeit + Nebenzeit': 'h',
    'Kosten Schweißer': '€',
    'Kosten SZ': '€',
    'Gesamtkosten': '€ / Stück',
}

# Define data types and properties
welding_properties = {
    'Kunde': str,
    'Gegenstand': str,
    'Zeichnungs- Nr.': str,
    'Ausführen Nr.': str,
    'Brennen': float,
    'Richten': float,
    'Heften_Zussamenb_Verputzen': float,
    'Anzeichnen': float,
    'Schweißen': float,
    'Schweißnahtnummer': float,
    'Schweißnaht': str,
    'Positionsnummer': str,
    'Lage': str,
    'Nahtlänge': float,
    'Nahtbreite': float,
    'Blechdicke': float,
    'Drahtdurchmesser': float,
    'Masse Drahtelektrode': float,
    'Stundensatz Schweißer': float,
    'Kosten Drahtelektrode': float,
    'benötigte Drahtrollen': float,
    'Schweißzeit gesamt': float,
    'Nebenzeit': float,
    'Schweißzeit + Nebenzeit': float,
    'Kosten Schweißer': float,
    'Kosten SZ': float,
    'Gesamtkosten': float,
}

units = {
    'Gewicht': 'kg',
    'Material Kosten': '€',
    'Prüfen , Doku': '€',
    'Strahlen / Streichen': '€',
    'techn. Bearb.': '€',
    'mech. Vorbearb.': '€',
    'mech. Bearbeitung': '€',
    'Zwischentransporte': '€',
    'transporte': '€',
    'Grenzkosten': '€',
    'Erlös': '€',
    'DB': '%',
    'Deckungsbeitrag': '€',
}

vk_st_0_field_mapping = {
    "Gewicht": "Fertigung Gesamt"
}

field_mapping = {
    'Kunde': 'Kunde',
    'Gegenstand': 'Benennung',  # Note the different field name here
    'Zeichnungs- Nr.': 'Zeichnungs- Nr.',
    'Ausführen Nr.': 'Ausführen Nr.'
}

material_cost_field_mapping = {
    "bis 90mm Einsatz": ("0 – 80mm", "Calculated Weight(Kg)"),
    "bis 90mm Fertig": ("0 – 80mm", "Delivery Weight(Kg)"),
    "bis 90mm Preis": ("0 – 80mm", "Price(€)"),
    "ab 100mm Einsatz": ("80 – 170mm", "Calculated Weight(Kg)"),
    "ab 100mm Fertig": ("80 – 170mm", "Delivery Weight(Kg)"),
    "ab 100mm Preis": ("80 – 170mm", "Price(€)"),
    "Profile Einsatz": ("Profile, Rohre etc.", "Calculated Weight(Kg)"),
    "Profile fertig": ("Profile, Rohre etc.", "Delivery Weight(Kg)"),
    "Profile Preis": ("Profile, Rohre etc.", "Price(€)")
}