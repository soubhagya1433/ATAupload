import streamlit as st
import pandas as pd
import io

from components.sidebar import project_selection
from db_utils import initialize_firestore_client
from data_objects import welding_properties, field_mapping, welding_units
from db_utils import get_all_collections, get_data_from_firestore, upload_data_to_firestore

def VK_0():

    db = initialize_firestore_client()

    selected_customer, selected_project = project_selection(db)
    # Initialize session state for each property
    if "vk_0_data" not in st.session_state:
        st.session_state.vk_0_data = {prop: "" for prop in welding_properties}
    # Define a key in session state to track the currently selected collection
    if 'current_collection' not in st.session_state:
        st.session_state.current_collection = None
    # Display a select box with all collection names
    collection_names = get_all_collections(db)
    # Update session state with selected collection
    firestore_data = {}
    details_data = {}
    vk_0_data = {}

    # Check if the selected collection has changed
    if st.session_state.current_collection != selected_project:
        st.session_state.current_collection = selected_project

        # Clear the previous data from session state
        st.session_state.vk_0_data = {prop: "" for prop in welding_properties}

        # Load new data from Firestore for the selected collection
        if selected_project:
            firestore_data = get_data_from_firestore(db, selected_project, 'Details')
            vk_0_data = get_data_from_firestore(db, selected_project, 'VK-0')

            # Update session state with new data
            if firestore_data:
                for app_field, firestore_field in field_mapping.items():
                    st.session_state.vk_0_data[app_field] = firestore_data.get(firestore_field, "")

    # Update session state with data from 'Details'
    if details_data:
        for app_field, firestore_field in field_mapping.items():
            if app_field in ['Kunde', 'Gegenstand', 'Zeichnungs- Nr.', 'Ausführen Nr.']:  # Fields from 'Details'
                st.session_state.data[app_field] = details_data.get(firestore_field, "")

    # Update session state with data from 'VK-0'
    if vk_0_data:
        for prop in welding_properties:
            if prop not in ['Kunde', 'Gegenstand', 'Zeichnungs- Nr.', 'Ausführen Nr.']:  # Remaining fields
                st.session_state.vk_0_data[prop] = vk_0_data.get(prop, "")

    st.title("Schweißen")
    with st.expander("Datenübertragung aus Excel"):
        uploaded_file = st.file_uploader("Datenübertragung aus Excel", type="xlsx")

    # If firestore_data is fetched, update the session state
    if firestore_data:
        for app_field, firestore_field in field_mapping.items():
            # Assuming 'Gegenstand' should map to 'Benennung' in Firestore
            if app_field == 'Gegenstand':
                firestore_field = 'Benennung'
            st.session_state.vk_0_data[app_field] = firestore_data.get(firestore_field, "")

    col1, col2, col3 = st.columns(3)
    calculation_tab, detail_tab, summary_tab = st.tabs(["Schweißnahtberechnung", "Details", "Zusammenfassung"])

    expander_properties_1 = ["Brennen", "Richten", "Heften_Zussamenb_Verputzen", "Anzeichnen", "Schweißen"]

    with calculation_tab:
        for prop in expander_properties_1:
            prompt = f"{prop} ({welding_units.get(prop, '')})"
            unique_key = f"expander1_{prop}"  # Unique key for expander text inputs
            st.session_state.vk_0_data[prop] = st.text_input(prompt, value=st.session_state.vk_0_data.get(prop, ''),
                                                             key=unique_key).strip()

    with detail_tab:


        expander_properties_2 = ["Schweißnahtnummer", "Schweißnaht", "Positionsnummer", "Lage", "Nahtlänge",
                                 "Nahtbreite", "Blechdicke", "Drahtdurchmesser", "Masse Drahtelektrode"]
        weld_types = ["Kehlnaht", "HV 40°", "HV40/15", "HV45°", "HV45°/15", "V 45°", "V60°", "Schrägen"]
        # for prop in expander_properties_2:
        #     if prop == "Schweißnaht":
        #         # Dropdown options for Schweißnaht

        #         default_value = st.session_state.vk_0_data.get(prop, '')
        #         if default_value not in weld_types:
        #             default_value = weld_types[0]  # Set default value if stored value not found
        #         selected_weld_type = st.selectbox(prop, weld_types, index=weld_types.index(default_value))
        #         st.session_state.vk_0_data[prop] = selected_weld_type
        #     else:
        #         prompt = f"{prop} ({welding_units.get(prop, '')})"
        #         unique_key = f"expander2_{prop}"  # Unique key for expander text inputs
        #         st.session_state.vk_0_data[prop] = st.text_input(prompt, value=st.session_state.vk_0_data.get(prop, ''),
        #                                                          key=unique_key).strip()
        # Define DataFrame columns based on expander_properties_2

        # Populate the first column with data from session_state


        columns = ["Schweißnahtnummer", "Schweißnaht", "Positionsnummer", "Lage", "Nahtlänge",
                   "Nahtbreite", "Blechdicke", "Drahtdurchmesser", "Masse Drahtelektrode"]

        values = [st.session_state.vk_0_data.get(prop, '') for prop in expander_properties_2]

        # Create an empty DataFrame with defined columns
        df = pd.DataFrame(columns=columns, data=[values])

        # Use data_editor to manage the DataFrame
        edited_df = st.data_editor(
            df,
            column_config={  # Specify column configurations
                "Schweißnahtnummer": "Schweißnahtnummer",
                "Schweißnaht": st.column_config.SelectboxColumn(
                    "Schweißnaht",
                    options=weld_types,
                    help="Select the type of weld",
                    default="Kehlnaht",
                ),

                "Positionsnummer": st.column_config.NumberColumn(
                    "Positionsnummer",
                    help="Enter the position number",
                    min_value=0,
                    step=1,
                ),
                "Lage": "Lage",
                "Nahtlänge": st.column_config.NumberColumn(
                    "Nahtlänge",
                    help="Enter the length of the weld",
                    min_value=0,
                    step=200,
                ),
                "Nahtbreite": st.column_config.NumberColumn(
                    "Nahtbreite",
                    help="Enter the width of the weld",
                    min_value=0,
                    step=100,
                ),
                "Blechdicke": st.column_config.NumberColumn(
                    "Blechdicke",
                    help="Enter the thickness of the plate",
                    min_value=0,
                    step=100,
                ),
                "Drahtdurchmesser": st.column_config.NumberColumn(
                    "Drahtdurchmesser",
                    help="Enter the diameter of the wire",
                    min_value=0,
                    step=100,
                ),
                "Masse Drahtelektrode": st.column_config.NumberColumn(
                    "Masse Drahtelektrode",
                    help="Enter the mass of the wire electrode",
                    min_value=0,
                    step=100,
                )
            },
            hide_index=True,
            use_container_width=True,
            num_rows="dynamic",

        )

    with summary_tab:
        expander_properties_3 = ["Stundensatz Schweißer", "Kosten Drahtelektrode", "benötigte Drahtrollen",
                                 "Schweißzeit gesamt", "Nebenzeit", "Schweißzeit + Nebenzeit", "Kosten Schweißer",
                                 "Kosten SZ", "Gesamtkosten"]
        col1, col2 = st.columns(2)
        for i, prop in enumerate(expander_properties_3):
            prompt = f"{prop} ({welding_units.get(prop, '')})"
            unique_key = f"expander3_{prop}"  # Unique key for expander text inputs
            if i % 2 == 0:
                st.session_state.vk_0_data[prop] = col1.text_input(prompt, value=st.session_state.vk_0_data.get(prop, ''),
                                                                  key=unique_key).strip()
            else:
                st.session_state.vk_0_data[prop] = col2.text_input(prompt, value=st.session_state.vk_0_data.get(prop, ''),
                                                                  key=unique_key).strip()

    col1, col2 = st.columns(2)
    # Display the calculated values
    col1.metric("Schweißzeit gesamt", st.session_state.vk_0_data.get("Schweißzeit gesamt", 0) + " h")
    col2.metric("Gesamtkosten", st.session_state.vk_0_data.get("Gesamtkosten", 0) + " €")

    # Define props_col3
    props = list(welding_properties.keys())
    props_col1 = props[:len(props) // 3]
    props_col2 = props[len(props) // 3: 2 * len(props) // 3]
    props_col3 = props[2 * len(props) // 3:]

    # Exclude properties listed under Eigenschaften 2 expander from iteration
    props_col3 = [prop for prop in props_col3 if prop not in expander_properties_3]

    # Iterate over props_col3
    for prop in props_col3:
        prompt = f"{prop} ({welding_units.get(prop, '')})"
        unique_key = f"col3_{prop}"  # Unique key for col3 text inputs
        st.session_state.vk_0_data[prop] = col3.text_input(prompt, value=st.session_state.vk_0_data.get(prop, ''),
                                                           key=unique_key).strip()

    def perform_calculations(data):
        # Convert relevant fields to numeric type
        numeric_fields = ['Brennen', 'Richten', 'Heften_Zussamenb_Verputzen', 'Anzeichnen', 'Schweißen']
        for field in numeric_fields:
            data[field] = float(data[field]) if data[field] else 0.0

        # Perform the specified calculations
        data['Brennen_VK_0'] = data['Brennen'] / 60
        data['Schlossern_VK_0'] = (data['Richten'] + data['Heften_Zussamenb_Verputzen'] + data['Anzeichnen']) / 60
        data['Schweißen_VK_0'] = data['Schweißen'] / 60
        return data

    # Convert the user input data dictionary to a pandas DataFrame
    df = pd.DataFrame(st.session_state.vk_0_data, index=[0])  # Specify index to create a DataFrame with one row

    # Transpose the DataFrame to have each column stacked vertically
    df_transposed = df.transpose()

    # Download Excel and JSON
    if st.button("Download Excel", use_container_width=True, type="secondary"):
        output = io.BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df_transposed.to_excel(writer, sheet_name='Sheet1',
                                   header=False)  # Set header to False to exclude column names
        output.seek(0)
        st.download_button("Download Excel File", output, key="download_excel", file_name="data.xlsx",
                           mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    if st.button("Upload to Database", use_container_width=True, type="primary"):
        # Extract the user input data
        user_input_data = {prop: st.session_state.vk_0_data[prop] for prop in welding_properties if
                           prop not in ['Kunde', 'Gegenstand', 'Zeichnungs- Nr.', 'Ausführen Nr.']}

        # Perform calculations on the input data
        user_input_data_calculated = perform_calculations(user_input_data)

        # Upload the original and calculated data to the database
        upload_data_to_firestore(db, selected_project, 'VK-0', user_input_data_calculated)

        st.success("Data uploaded successfully!")