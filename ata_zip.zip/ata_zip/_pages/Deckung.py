import streamlit as st
import pandas as pd
import io

from components.sidebar import project_selection
from db_utils import initialize_firestore_client, get_all_collections, get_data_from_firestore, upload_data_to_firestore
from db_utils import get_customers, get_projects, get_project_data
from data_objects import deckung_properties, units, field_mapping, vk_st_0_field_mapping, material_cost_field_mapping


# Function to safely convert a value to float
def try_convert_to_float(value, default=0.0):
    try:
        return float(value) if value else default
    except ValueError:
        return default


def grenz_calculate(data):
    numeric_fields = ['Glühen', 'Prüfen , Doku', 'Strahlen / Streichen', 'techn. Bearb.', 'mech. Vorbearb.',
                      'mech. Bearbeitung',
                      'Zwischentransporte', 'transporte', 'Material Kosten']

    for field in numeric_fields:
        data[field] = float(data[field]) if data[field] else 0.0

    # Access 'Fertigung EUR' from session state
    data['fertigung_eur'] = st.session_state.get('fertigung_eur', 0.0)
    data['Grenzkosten'] = data['fertigung_eur'] + data['Material Kosten'] + data['Glühen'] + data[
        'Prüfen , Doku'] + \
                          data['Strahlen / Streichen'] + data['techn. Bearb.'] + data['mech. Vorbearb.'] + data[
                              'mech. Bearbeitung'] + data['Zwischentransporte'] + data['transporte']
    return data


def deckung_excel_download():
    data_dict = {
        'Kunde': st.session_state.deckung_data['Kunde'],
        'Benennung': st.session_state.deckung_data['Benennung'],
        'Anfr. Nr.': st.session_state.deckung_data['Zeichnungs- Nr.'],
        'Gewicht': st.session_state.deckung_data['Gewicht'],
        'Material': st.session_state.deckung_data['Material Kosten'],
        'Glühen': 0,
        'Prüfen , Doku': st.session_state.deckung_data['Prüfen , Doku'],
        'Strahlen / Streichen': st.session_state.deckung_data['Strahlen / Streichen'],
        'techn. Bearb.': st.session_state.deckung_data['techn. Bearb.'],
        'mech. Vorbearb.': st.session_state.deckung_data['mech. Vorbearb.'],
        'mech. Bearbeitung': st.session_state.deckung_data['mech. Bearbeitung'],
        'Zwischentransporte': st.session_state.deckung_data['Zwischentransporte'],
        'Transporte': st.session_state.deckung_data['transporte'],
        'Grenzkosten': (
                st.session_state.deckung_data['Prüfen , Doku'] +
                st.session_state.deckung_data['Strahlen / Streichen'] +
                st.session_state.deckung_data['techn. Bearb.'] +
                st.session_state.deckung_data['mech. Vorbearb.'] +
                st.session_state.deckung_data['mech. Bearbeitung'] +
                st.session_state.deckung_data['Zwischentransporte'] +
                st.session_state.deckung_data['transporte']
        ),
        'Erlös': st.session_state.erlos,
        'DB': st.session_state.deckungsbeitrag,
        'Soll 10%': st.session_state.erlos * 0.1,
        'Deckungsbeitrag': st.session_state.deckungsbeitrag
    }
    data_dict.update({
        'Erlös': st.session_state.erlos,
        'DB (%)': st.session_state.db_percentage,
        'Deckungsbeitrag': st.session_state.deckungsbeitrag,
        'Soll 10%': st.session_state.erlos * 0.1
    })

    # Convert the dictionary to a DataFrame
    df = pd.DataFrame([data_dict])
    excel_file = io.BytesIO()
    with pd.ExcelWriter(excel_file, engine='xlsxwriter') as writer:
        df.T.to_excel(writer, sheet_name='user_data', header=False)
    excel_file.seek(0)

    # Download the Excel file using st.download_button
    st.download_button(label="Click here to download the Excel file", key="download_excel", data=excel_file,
                       file_name="user_data.xlsx",
                       mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


def load_selected_collection_data(selected_collection, df, db):
    # Load new data from Firestore for the selected collection
    if selected_collection:
        existing_deckung_data = get_data_from_firestore(db, selected_collection, 'Deckung')
        if existing_deckung_data:
            # Update session state with existing data
            for key, value in existing_deckung_data.items():
                if key in st.session_state.deckung_data:
                    st.session_state.deckung_data[key] = value
                    # st.write(f"{key}: {value}")
            # st.write("Debug - Updated Session State:", st.session_state.deckung_data)
        details_data = get_data_from_firestore(db, selected_collection, 'Details')
        if details_data:
            for app_field, firestore_field in field_mapping.items():
                st.session_state.deckung_data[app_field] = details_data.get(firestore_field, "")
        vk_st_0_data = get_data_from_firestore(db, selected_collection, 'VK-ST-0')
        if vk_st_0_data:
            for app_field, firestore_field in vk_st_0_field_mapping.items():
                st.session_state.deckung_data[app_field] = vk_st_0_data.get(firestore_field, "")
            for firestore_field, (row_index, column_name) in material_cost_field_mapping.items():
                if firestore_field in vk_st_0_data:
                    value = float(vk_st_0_data[firestore_field]) if vk_st_0_data[firestore_field] else 0.0
                    df.at[row_index, column_name] = value
            st.session_state['Material'] = df.to_dict(orient="index")
        try:
            deckungsbeitrag_data = get_data_from_firestore(db, selected_collection, 'Deckung')

            if deckungsbeitrag_data:
                # Safely convert to float, default to 0.0 if conversion fails
                st.session_state.erlos = try_convert_to_float(deckungsbeitrag_data.get('Erlös', 0.0))
                st.session_state.deckungsbeitrag = try_convert_to_float(
                    deckungsbeitrag_data.get('Deckungsbeitrag', 0.0))
                st.session_state.db_percentage = try_convert_to_float(deckungsbeitrag_data.get('DB (%)', 0.0))

            else:
                st.write("No data found for the selected collection.")

        except Exception as e:
            st.error(f"An error occurred while")


def product_details():
    col1, col2 = st.columns(2)
    for prop in ['Gewicht', 'Material Kosten']:
        prompt = f"{prop}"
        if prop in units:
            prompt += f" ({units[prop]})"
        if prop == 'Material Kosten':
            # Default to the stored total cost if available, otherwise use the current value
            default_value = st.session_state.get('total_material_cost',
                                                 float(st.session_state.deckung_data[prop]) if
                                                 st.session_state.deckung_data[prop] else 0.0)
            st.session_state.deckung_data[prop] = col1.number_input(prompt, key=f"{prop}_input", value=default_value,
                                                                  step=0.1)
        elif deckung_properties[prop] == float:
            current_value = float(st.session_state.deckung_data[prop]) if st.session_state.deckung_data[
                prop] else 0.0
            st.session_state.deckung_data[prop] = col2.number_input(prompt, key=f"{prop}_input", value=current_value,
                                                                  step=0.1)

        else:
            st.session_state.deckung_data[prop] = col2.text_input(prompt,
                                                                key=f"{prop}_input",
                                                                value=st.session_state.deckung_data[prop]).strip()

def Deckung():
    # Initialize Firestore client
    db = initialize_firestore_client()

    session_state_dict = {
        'deckung_data': {prop: "" for prop in deckung_properties},
        'Material': pd.DataFrame(
            index=["0 – 80mm", "80 – 170mm", "Profile, Rohre etc.", "Schrauben, Schild", "Zuschlag", "Total"],
            columns=["Calculated Weight(Kg)", "Delivery Weight(Kg)", "Price(€)", "Price per Kg(€/Kg)"]
        ).to_dict(orient='index'),
        'Erlös': 0.0,
        'Processing_Time': 0.0,
        'Deckungsbeitrag': 0.0,
        "DB (%)": 0.0,
        "total_material_cost": 0.0,
        "current_collection": None
    }
    for key, value in session_state_dict.items():
        st.session_state[key] = value

    # Now 'df' is defined from the session state
    df = pd.DataFrame.from_dict(st.session_state['Material']).transpose()

    collection_names = get_all_collections(db)
    selected_customer, selected_project = project_selection(db)




    # Load new data from Firestore for the selected collection
    load_selected_collection_data(selected_project, df, db)
    st.title("Deckung")
    product_details()

    material_cost_tab, deckungsbeitrag_tab, processing_time_tab, grenzkosten_tab = st.tabs(["Materialkosten", "Deckungsbeitrag", "Bearbeitungszeit", "Grenzkosten"])

    with material_cost_tab:
        # Display the DataFrame using Streamlit's dataframe function
        st.dataframe(df, use_container_width=True)

        if st.button('Calculate Totals', key="Calculate_Totals", use_container_width=True, type="secondary"):
            df = pd.DataFrame.from_dict(st.session_state['Material']).transpose()

            # Convert the DataFrame columns to numeric values where possible
            for col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='ignore')

            # Compute the total for each column (excluding "Price per kg") and update the "Total" row values
            df.loc["Total", ["Calculated Weight(Kg)", "Delivery Weight(Kg)", "Price(€)"]] = df.loc[
                                                                                            :"Zuschlag",
                                                                                            ["Calculated Weight(Kg)",
                                                                                             "Delivery Weight(Kg)",
                                                                                             "Price(€)"]].sum()
            # Update the session state with the edited DataFrame
            st.session_state['Material'] = df.to_dict(orient="index")

            # Store the total material cost in session state
            st.session_state['total_material_cost'] = df.loc["Total", "Price(€)"]

            # Update the "Material Kosten" in "Product Details" if it's already been rendered
            if 'Material Kosten' in st.session_state.deckung_data:
                st.session_state.deckung_data['Material Kosten'] = st.session_state[
                    'total_material_cost']  # this is where the Material Kosten is being used

    with deckungsbeitrag_tab:
        # Input fields
        st.session_state.erlos = st.number_input("Erlös", value=st.session_state.erlos)
        st.session_state.db_percentage = st.number_input("DB (%)", value=st.session_state.db_percentage, step=0.01)
        st.session_state.deckungsbeitrag = st.number_input("Deckungsbeitrag", value=st.session_state.deckungsbeitrag)

    # Fetch values from Firestore for VK-0 document
    vk_0_data = get_data_from_firestore(db, selected_project, 'VK-0')
    if vk_0_data:
        # Update session state with VK-0 data
        st.session_state.deckung_data['Brennen_VK_0'] = vk_0_data.get('Brennen_VK_0', "")
        st.session_state.deckung_data['Schlossern_VK_0'] = vk_0_data.get('Schlossern_VK_0', "")
        st.session_state.deckung_data['Schweißen_VK_0'] = vk_0_data.get('Schweißen_VK_0', "")

    df1 = pd.DataFrame([
        {"Process": "Brennen", "Eur/hour": 0, "Hour": st.session_state.deckung_data.get('Brennen_VK_0', 0)},
        {"Process": "Schlossern", "Eur/hour": 0, "Hour": st.session_state.deckung_data.get('Schlossern_VK_0', 0)},
        {"Process": "Schweißen", "Eur/hour": 0, "Hour": st.session_state.deckung_data.get('Schweißen_VK_0', 0)},
        {"Process": "sonstiges", "Eur/hour": 0, "Hour": 0},
    ])

    with processing_time_tab:
        gewicht_value = st.session_state.deckung_data.get('Gewicht', 0)
        edited_df = st.data_editor(df1, use_container_width=True)

        if st.button("Calculate Total Time", use_container_width=True, key="Calculate_Total_Time", type="secondary"):
            # Perform the calculations
            gesamtstunden = df1["Hour"].sum()  # Sum of hours for all processes
            stunden_tonne = gesamtstunden / gewicht_value * 1000  # Hours per tonne

            st.session_state.deckung_data["Gesamtstunden"] = gesamtstunden
            st.session_state.deckung_data["Stunden / Tonne"] = stunden_tonne
            # Display the calculated results
            col1, col2 = st.columns(2)
            col1.text_input("Gesamtstunden", value=gesamtstunden)
            col2.text_input("Stunden / Tonne", value=stunden_tonne)

    # Create an expander for 'Grenzkosten'
    with grenzkosten_tab:
        col1, col2 = st.columns(2)
        for i, prop in enumerate(['Glühen', 'Prüfen , Doku', 'Strahlen / Streichen', 'techn. Bearb.', 'mech. Vorbearb.',
                     'mech. Bearbeitung',
                     'Zwischentransporte', 'transporte']):

            prompt = f"{prop}"
            if prop in units:
                prompt += f" ({units[prop]})"
            if i % 2 == 0:
                st.session_state.deckung_data[prop] = col1.text_input(prompt,
                                                                value=st.session_state.deckung_data[prop]).strip()
            else:
                st.session_state.deckung_data[prop] = col2.text_input(prompt,
                                                                value=st.session_state.deckung_data[prop]).strip()

        # Total calculation
        # Calculate Grenzkosten directly without a button
        grenz_data = grenz_calculate(st.session_state.deckung_data)

    st.divider()
        # Display the calculated Grenzkosten


    # Combine data for downloads
    combined_data = {
        **st.session_state["deckung_data"],  # Project and Product Details
        **st.session_state['Material'],  # Material Cost Details
        # **st.session_state['Processing_Time'],
        'Erlös': st.session_state.erlos,
        'DB (%)': st.session_state.db_percentage,
        'Deckungsbeitrag': st.session_state.deckungsbeitrag,
    }

    # Convert the combined data to a pandas DataFrame
    df = pd.DataFrame([combined_data])
    col1, col2, col3, col4 = st.columns(4)
    col1.metric("Erlös:", f"{st.session_state.erlos} €")
    col2.metric("DB (%):", f"{st.session_state.db_percentage} %")
    col3.metric("Deckungsbeitrag:", f"{st.session_state.deckungsbeitrag} €")
    col4.metric("Calculated Grenzkosten:", f"{grenz_data['Grenzkosten']} €")


    # Add a button to download the data as Excel
    if st.button("Download as Excel", key="Deckung_Excel", use_container_width=True, type="secondary"):
        deckung_excel_download()

    if st.button("Upload to Database", key="upload_to_db", use_container_width=True, type="primary"):
        # Prepare the data to upload
        combined_data_to_upload = {
            **st.session_state.deckung_data,  # Project and Product Details
            **st.session_state['Material'],  # Material Cost Details
            'Erlös': st.session_state.erlos,
            'DB (%)': st.session_state.db_percentage,
            'Deckungsbeitrag': st.session_state.deckungsbeitrag,
        }

        # Call the function to upload data to Firestore
        try:
            upload_data_to_firestore(db, selected_project, "Deckung", combined_data_to_upload)

        except Exception as e:
            st.error(f"An error occurred: {e}")
