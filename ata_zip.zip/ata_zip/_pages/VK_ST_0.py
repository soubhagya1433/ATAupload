import streamlit as st

def VK_ST_0():
    st.title("VK-ST-0")