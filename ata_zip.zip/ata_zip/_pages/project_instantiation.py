import streamlit as st
from db_utils import initialize_firestore_client, get_all_document_ids
from components.columns import two_text_columns, two_columns
from data_objects import deckung_properties, vk_st0_data, vk0_data

def instantiate_db_project(kunde, benennung, zeichnungs_nr, ausfuehren_nr, db):
    doc_ref = db.collection(zeichnungs_nr).document('Details')
    doc = doc_ref.get()
    if doc.exists:
        return False
    else:
        project_data = {
            "Kunde": kunde,
            "Benennung": benennung,
            "Ausführen Nr": ausfuehren_nr,
            "Zeichnungs- Nr.": zeichnungs_nr
        }
        doc_ref.set(project_data)

        vk_st0_doc_ref = db.collection(zeichnungs_nr).document('VK-ST-0')
        vk_st0_doc_ref.set(vk_st0_data)
        st.success("'VK-ST-0' document created successfully.")

        # Create VK-0 document and add to Firebase
        vk0_doc_ref = db.collection(zeichnungs_nr).document('VK-0')
        vk0_doc_ref.set(vk0_data)
        st.success("'VK-0' document created successfully.")

        # Create Deckung document and add to Firebase
        deckung_doc_ref = db.collection(zeichnungs_nr).document('Deckung')
        deckung_data = {prop: 0 for prop in deckung_properties}
        deckung_doc_ref.set(deckung_data)

        st.success("'Deckung' document created successfully.")
        return True


def project_instantiation():
    db = initialize_firestore_client()
    customers = get_all_document_ids(db, 'Customers')

    st.title('Neues Projekt erstellen')
    with st.expander('Projekt Details', expanded=True):
        # Input fields for project instantiation
        new_customer = st.checkbox('Neuer Kunde?')
        if not new_customer:
            kunde = st.selectbox('Kunde', customers)
        else:
            col1, col2 = st.columns(2)
            kunde = col1.text_input('Kunden-Name', key='new_customer')
            kunden_nr = col2.number_input('Kunden-Nr.', key='new_customer_kunden_nr', min_value=0, max_value=99999)
            st.divider()
            street = st.text_input('Straße', key='new_customer_adress')
            col1, col2 = st.columns(2)
            with col1:
                city = st.text_input('Stadt', key='new_customer_city')
            with col2:
                plz= st.number_input('PLZ', key='new_customer_plz', min_value=0, max_value=99999)
        benennung, zeichnungs_nr = two_text_columns("Benennung", "Zeichnungs-Nr.")
        ausfuehren_nr = st.number_input('Anzahl (Ausführen Nr.)', min_value=0, max_value=10000)

    with st.expander('Projekt Dokumente'):
        project_picture = st.file_uploader('Bild 3D Objekt', type=['png', 'jpg', 'jpeg'])
        if project_picture:
            st.image(project_picture, caption='Uploaded Image', use_column_width=True)

        project_documents = st.file_uploader('Upload Projekt Documente',
                                             type=['pdf', 'docx', 'doc', 'xlsx', 'xls', 'pptx', 'ppt', 'txt'],
                                             accept_multiple_files=True)

    submit_button = st.button(label='Erstelle neues Projekt', use_container_width=True, type="primary")
    if submit_button:
        success = instantiate_db_project(kunde, benennung, zeichnungs_nr, ausfuehren_nr, db)
        if new_customer:
            customer_data = {
                'Kunden-Nr.': kunden_nr,
                'Name': kunde,
                "Address": f"{street}, {plz} {city}",
                "Project_List": [zeichnungs_nr]
            }
            doc_ref = db.collection('Customers').document(kunde)
            doc_ref.set(customer_data)
            st.success('Neuer Kunde erfolgreich angelegt!')
        else:
            doc_ref = db.collection('Customers').document(kunde)
            doc = doc_ref.get()
            if doc.exists:
                customer_data = doc.to_dict()
                customer_data['Project_List'].append(zeichnungs_nr)
                doc_ref.set(customer_data)
                st.success('Kunde erfolgreich aktualisiert!')
            else:
                st.error('Kunde nicht gefunden!')

        if success:
            st.success('Projekt wurde erfolgreich erstellt!')
            # Clear the input fields
            kunde = ''
            benennung = ''
            zeichnungs_nr = ''
            ausfuehren_nr = 0
            project_picture = None
            project_documents = None
        else:
            st.error('A project with this Zeichnungs Nr already exists.')