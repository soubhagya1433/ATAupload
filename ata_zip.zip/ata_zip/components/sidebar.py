import streamlit as st
from streamlit_option_menu import option_menu
from db_utils import get_customers, get_projects


def page_navigation(image):
    from _pages import VK_ST_0, VK_0, Deckung, project_instantiation, Angebot
    tabs = {
        "Neues Projekt": project_instantiation,
        "Materialerfassung": VK_ST_0,
        "Schweißanalyse": VK_0,
        "Deckung": Deckung,
        "Angebot": Angebot
    }

    st.image(image, use_column_width=True)
    selected_tab = option_menu("App Navigation", list(tabs.keys()), icons=None)
    with st._main:
        tabs[selected_tab]()

def project_selection(db):
    from PIL import Image
    image = Image.open('logo_ata.png')
    with st.sidebar:
        st.image(image, use_column_width=True)
    with st.sidebar:
        with st.container(border=True):
            customer_names = get_customers(db)
            selected_customer = st.selectbox("Customer", customer_names, index=1, key='selected_customer')
            project_names = get_projects(db, selected_customer)
            selected_project = st.selectbox("Project", project_names, index=1, key='selected_project')
            # project_data = get_project_data(selected_project)
    return selected_customer, selected_project