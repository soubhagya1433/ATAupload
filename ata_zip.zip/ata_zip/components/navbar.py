import streamlit as st
from streamlit_navigation_bar import st_navbar


styles = {
    "nav": {
        "background-color": "rgb(0, 81, 158)",
        "justify-content": "space-between",
    },
    "div": {
        "max-width": "80rem",
    },
    "img": {
        "padding-right": "14px",
    },
    "span": {
        "border-radius": "0.5rem",
        "color": "white",
        "margin": "0 0.125rem",
        "padding": "0.4375rem 0.625rem",
    },
    "active": {
        "background-color": "white",
        "color": "var(--text-color)",
        "font-weight": "normal",
        "padding": "5px",
    },
    "hover": {
        "background-color": "white",
        "color": "var(--text-color)",
        "font-weight": "normal",
        "padding": "5px",
    }

}

def page_navigation(image):
    from _pages import VK_ST_0, VK_0, Deckung, project_instantiation, Angebot
    tabs = {
        "Neues Projekt": project_instantiation,
        "Materialerfassung": VK_ST_0,
        "Schweißanalyse": VK_0,
        "Deckung": Deckung,
        "Angebot": Angebot
    }
    options = {
    "show_menu": True,
    "show_sidebar": True,
    }   
        
    # page = st_navbar(["Home", "Documentation", "Examples", "Community", "About"])
    # st.write(page)

    #st.image(image, use_column_width=True)
    logo_path = "./logo_ata.svg"
    
    #selected_tab = option_menu("App Navigation", list(tabs.keys()), icons=None)
    selected_tab = st_navbar(list(tabs.keys()), logo_page="Neues Projekt", styles=styles, logo_path=logo_path, options=options)
    with st._main:
        tabs[selected_tab]()