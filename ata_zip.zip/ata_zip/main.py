import streamlit as st
from PIL import Image
from google.cloud import firestore
from google.oauth2 import service_account
from components.sidebar import page_navigation
from components.columns import two_text_columns
from components.navbar import page_navigation
from db_utils import initialize_firestore_client
from data_objects import deckung_properties, vk_st0_data, vk0_data, customers

from PIL import Image
image = Image.open('logo_ata.png')

st.set_page_config(page_title="ATA Angebotserstellung", page_icon=image, layout="wide", menu_items={"Get help": None, "Report a bug": None, "About": None})
# Initialize Firestore client
db = initialize_firestore_client()

button_css = '''
button[kind="secondary"] {
    background-color: lightgrey;
}
'''
# st.markdown(f'<style>{button_css}</style>', unsafe_allow_html=True)

css = '''
[data-testid="metric-container"] {
    width: fit-content;
    margin: auto;
}

[data-testid="metric-container"] > div {
    width: fit-content;
    margin: auto;
}

[data-testid="metric-container"] label {
    width: fit-content;
    margin: auto;
}
'''

# I usually dump any scripts at the bottom of the page to avoid adding unwanted blank lines
# st.markdown(f'<style>{css}</style>', unsafe_allow_html=True)

# Inject custom CSS to set the width of the sidebar
# st.markdown(
#     """
#     <style>
#         section[data-testid="stSidebar"] {
#             width: 20% !important; # Set the width to your desired value
#         }
#     </style>
#     """,
#     unsafe_allow_html=True,
# )

def instantiate_session_state():
    session_state_dict = {
        'main_data': {},
        'project_data': {},
        'vk_st0_data': {},
        'vk0_data': {},
        'deckung_data': {}
    }
    for key, value in session_state_dict.items():
        st.session_state[key] = value


if __name__ == '__main__':
    page_navigation(image)
    instantiate_session_state()





